
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class StringCalculator12Applicationq1Test {

    @Test
    public void testAddEmptyString() {
        StringCalculator12Applicationq1 calculator = new StringCalculator12Applicationq1();
        assertEquals(0, calculator.add(""));
    }

    @Test
    public void testAddOneNumber() {
        StringCalculator12Applicationq1 calculator = new StringCalculator12Applicationq1();
        assertEquals(1, calculator.add("1"));
    }

    @Test
    public void testAddTwoNumbers() {
        StringCalculator12Applicationq1 calculator = new StringCalculator12Applicationq1();
        assertEquals(3, calculator.add("1,2"));
    }

    @Test
    public void testAddMultipleNumbers() {
        StringCalculator12Applicationq1 calculator = new StringCalculator12Applicationq1();
        assertEquals(6, calculator.add("1,2,3"));
    }

    @Test
    public void testAddNewLineBetweenNumbers() {
        StringCalculator12Applicationq1 calculator = new StringCalculator12Applicationq1();
        assertEquals(6, calculator.add("1\n2,3"));
    }

    @Test
    public void testAddDifferentDelimiter() {
        StringCalculator12Applicationq1 calculator = new StringCalculator12Applicationq1();
        assertEquals(3, calculator.add("//;\n1;2"));
    }

    @Test
    public void testNegativeNumberThrowsException() {
        StringCalculator12Applicationq1 calculator = new StringCalculator12Applicationq1();
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            calculator.add("1,-2,3");
        });
        assertEquals("negative numbers not allowed: -2", exception.getMessage());
    }

    @Test
    public void testMultipleNegativeNumbersThrowException() {
        StringCalculator12Applicationq1 calculator = new StringCalculator12Applicationq1();
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            calculator.add("1,-2,-3,4");
        });
        assertEquals("negative numbers not allowed: -2, -3", exception.getMessage());
    }
}
