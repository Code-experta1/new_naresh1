package com.example.StringCalculator12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StringCalculator12ApplicationTests {

	@Test
	void contextLoads() {
	}

}
