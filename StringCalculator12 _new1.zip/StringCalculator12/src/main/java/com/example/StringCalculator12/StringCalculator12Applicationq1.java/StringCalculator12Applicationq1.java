import java.util.ArrayList;
import java.util.List;

public class StringCalculator12Applicationq1 {

    public int add(String numbers) {
        if (numbers.isEmpty()) {
            return 0;
        }

        String delimiter = getDelimiter(numbers);
        numbers = getNumbers(numbers, delimiter);

        String[] nums = numbers.split(delimiter);
        List<Integer> negatives = new ArrayList<>();
        int sum = 0;
        for (String num : nums) {
            int n = Integer.parseInt(num);
            if (n < 0) {
                negatives.add(n);
            }
            sum += n;
        }

        if (!negatives.isEmpty()) {
            throw new IllegalArgumentException("negative numbers not allowed: " + negatives.toString().replaceAll("[\\[\\]]", ""));
        }

        return sum;
    }

    private String getDelimiter(String numbers) {
        if (numbers.startsWith("//")) {
            int delimiterIndex = numbers.indexOf("\n");
            return numbers.substring(2, delimiterIndex);
        }
        return ",|\n";
    }

    private String getNumbers(String numbers, String delimiter) {
        if (numbers.startsWith("//")) {
            int delimiterIndex = numbers.indexOf("\n");
            return numbers.substring(delimiterIndex + 1);
        }
        return numbers;
    }
}